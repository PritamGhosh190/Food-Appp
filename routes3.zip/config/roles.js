const ROLE = {
  admin: "admin",
  operator: "seller",
  analytics: "user",
};

module.exports = { ROLE };
