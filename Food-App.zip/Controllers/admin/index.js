const getUsers = require("./getUser");
const getSellers = require("./getSeller");


module.exports = {
  getUsers,
  getSellers
  };