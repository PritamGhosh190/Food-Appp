const pieChart = require('./pieChart')

module.exports = {
  pieChart,
}